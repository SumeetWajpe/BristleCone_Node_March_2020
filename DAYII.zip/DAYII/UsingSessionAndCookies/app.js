var express = require('express');
var session = require('express-session');
var ckparser = require('cookie-parser');

var app = express();

app.use(ckparser());
app.use(session({
    secret:'anyString', // used for identifying session & generate ID
    saveUninitialized:true, // save unitialized session
    resave:true  // save after making any session state changes
}));

app.get('/',(req,res)=>{
        // create a session
        // store some value in session (session state)
        // have some cookie information
        res.send('Out first Cookie and Session Mgmnt !');

        console.log(req.cookies);
        console.log("====================================");
        console.log(req.session);
        console.log('----------------------------------------------------------------------------');


        var s = req.session; // access the session state & store the data
        s.Value = "Actual Session State value !" ; // js object | array | JSON

});

// any other request that do not match the urls provided
app.use((req,res)=>{
    res.statusCode = 404;
    res.send("<h1 style='color:red'> Resource not Found ! </h1>");// sendFile('ErrorPage.html')
});
app.listen(5000,()=>console.log('Server listening @ port 5000 !'));