var express = require('express');
var router = express.Router();
router.route('/products').get((req,res)=>{   
    res.render('products',{title:'Products !',products: [
        {name:'LEDTV',price:40000},
        {name:'LCDTV',price:30000},
        {name:'OLEDTV',price:80000},
        {name:'COLEDTV',price:100000}
    ]})
});
module.exports = router;