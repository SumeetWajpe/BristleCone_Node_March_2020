var express = require('express');
var router = express.Router();
router.route('/index').get((req,res)=>{
    // a message to be rendered
    // message is passed to index.pug
    res.render('index',{message:'Rendered Using Pug Engine !'})
});

module.exports = router;