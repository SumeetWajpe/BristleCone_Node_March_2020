// import express,pug
// write pug file (html template)
// integrate pug with express (set)
// render html and send response to client

var express = require('express');
var app = express();
var path = require('path');
var routes = require('./routes/index');
var proutes = require('./routes/products');


app.set("views",path.join(__dirname,"views"));
app.set("view engine","pug");
app.get('/',(req,res)=>{
    res.send('<h1> Use /index for some HTML ! </h1>')
});
app.use('/',routes);
app.use('/',proutes);
app.use((req,res)=>{
    res.statusCode = 404;
    res.send("<h1 style='color:red'> Resource not Found ! </h1>");// sendFile('ErrorPage.html')
});
app.listen(5000,()=>console.log('Server listening @ port 5000 !'));