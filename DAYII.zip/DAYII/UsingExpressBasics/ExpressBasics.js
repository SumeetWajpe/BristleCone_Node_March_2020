var express = require('express');
var app = express(); // represents our application

// createServer !
app.get('/',(req,res)=>{
    res.send("This is Hello from Express !");
});

app.listen(5000,()=>console.log('Server listening @ port 5000 !'));