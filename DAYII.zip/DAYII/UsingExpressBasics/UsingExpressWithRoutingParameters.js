var express = require('express');
var app = express(); // represents our application
var router = express.Router();
router.route('/products/:pname').get((req,res)=>{
     var products = [
        {name:'LEDTV',price:40000},
        {name:'LCDTV',price:30000},
        {name:'OLEDTV',price:80000},
        {name:'COLEDTV',price:100000}
    ];
    var pName = req.params.pname;
    var theProduct = products.find(p=> p.name == pName);

    if(theProduct){
        res.json(theProduct);
    }else{
        res.json(products);
    }
});
app.use('/',router);// adding router
app.get('/',(req,res)=>{   
    res.sendFile('Index.html',{root:__dirname});  
});
app.use((req,res)=>{
    res.statusCode = 404;
    res.send("<h1 style='color:red'> Resource not Found ! </h1>");// sendFile('ErrorPage.html')
});
app.listen(5000,()=>console.log('Server listening @ port 5000 !'));