var express = require('express');
var app = express(); // represents our application
var router = express.Router();

router.route('/products').get((req,res)=>{
     var products = [
        {name:'LED TV',price:40000},
        {name:'LCD TV',price:30000},
        {name:'OLED TV',price:80000},
        {name:'Curved OLED TV',price:100000}
    ];
    res.json(products);
});
app.use('/',router);

app.get('/',(req,res)=>{   
    res.sendFile('Index.html',{root:__dirname});  
});

app.listen(5000,()=>console.log('Server listening @ port 5000 !'));