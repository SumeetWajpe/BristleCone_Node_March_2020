var express = require('express');
var app = express(); // represents our application

// createServer !
app.get('/',(req,res)=>{
    // var products = [
    //     {name:'LED TV',price:40000},
    //     {name:'LCD TV',price:30000},
    //     {name:'OLED TV',price:80000},
    //     {name:'Curved OLED TV',price:100000}
    // ];
    res.sendFile('Index.html',{root:__dirname});
   //res.set("Content-Type","application/json");
    //res.json(products);
});

app.listen(5000,()=>console.log('Server listening @ port 5000 !'));