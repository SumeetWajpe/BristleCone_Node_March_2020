var express = require('express');
var app = express();
var bodyParser = require('body-parser');
// var router = express.Router();
// router.route('/login').post((req,res)=>{

// });
//app.use('/',router);

app.get('/', function (req, res) {
    res.sendFile('Login.html', { root: __dirname });
});
//body-parser is a middleware !
// add middleware using use !
app.use(bodyParser.urlencoded(
    {
        extended: true
    }
));

app.post('/login', (req, res) => {
    // know the details sent from client !
    console.log('Posted !');
    var uname = req.body.username;
    var upwd = req.body.password;
    console.log('U Passed -> Uname : ' +uname + " , Password : " + upwd);
    res.send("Success");
});

app.use((req, res) => {
    res.statusCode = 404;
    res.send("<h1 style='color:red'> Resource not Found ! </h1>");// sendFile('ErrorPage.html')
});
app.listen(5000, () => {
    console.log('Server running at port 5000 !')
});