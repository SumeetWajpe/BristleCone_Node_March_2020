var http = require('http');
var fs = require('fs');

var server = http.createServer(function (req, res) {
    fs.readFile('Index.html',function(err,dataFromFile){
        console.log('Serving the response !');
        if(err){
            // log the error !
        }
        else if(dataFromFile){
            res.statusCode = 200;
            res.setHeader('Content-Type', 'text/html');
            res.end(dataFromFile.toString());
        }
    });
});

server.listen(3000, function () {
    console.log('Server listening on port 3000 !');
});
// Why Express ??


// Disadvantages of node dev (only)
    // -> Slow App Development
    // -> Dev has to be very specific and write lower level API [ex. fs.readFile()]
    // -> common API (method) for all request

// Advantages of Express
    // All the above disadvantages taken care !
    // -> supports routing
    // -> supports rich API
    // -> developers need to write less code !
    // -> integrates with html template engines [handlebar,mustache,pug(jade earlier)]
    //  -> apis for sessions
    // localhost:3000/posts  -> posts [JSON]

// localhost:3000/  -> Index.html

// localhost:3000/  -> script.js + css