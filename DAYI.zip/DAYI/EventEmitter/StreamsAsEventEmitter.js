var fs = require('fs');

var readableStream = fs.createReadStream('Input.txt'); // return a EventEmitter object
var writableStream = fs.createWriteStream('Output.txt');

readableStream.setEncoding('UTF-8');
var allData = "";
readableStream.on('data',function(chunk){
        allData +=chunk;
        console.log('>>>>>>>>>>>> CHUNK >>>>>>>>>>');       
});

readableStream.on('end',function(){
        writableStream.write(allData);
        writableStream.end();
});

// readableStream.pipe(writableStream);