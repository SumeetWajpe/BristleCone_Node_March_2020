var EventEmitter = require('events').EventEmitter;
function GetCount(maxIteration){
var evt = new EventEmitter();
// biz logic
// emit start  -> When loop start
// emit count -> pass current count
//emit error  -> pass current count
//emit finished -> done !
process.nextTick(function(){
    evt.emit('start');
    var cnt = 0;
   var t = setInterval(function(){
        e.emit('count',++cnt);

        if(cnt == 8){
            e.emit('error',cnt);
            clearInterval(t);
        }
        if(cnt == maxIteration){
            e.emit('finished');
            clearInterval(t);
        }
    },1000);
});
return evt;
}
var e = GetCount(10);// return a EventEmitter object
e.on('start',function(){
    console.log('Starting Loop..');
});
e.on('count',function(currCount){
    console.log('Received Count : '+ currCount);
});
e.on('error',function(currCount){
    console.log('Error Received, Current Count : '+ currCount);
});
e.on('finished',function(){
    console.log('Done Iterating !');
});