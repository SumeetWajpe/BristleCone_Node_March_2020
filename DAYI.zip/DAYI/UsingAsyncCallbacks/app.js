
// Biz logic !
var maxTime = 1000;
function EvenNumberDoubler(theNumber,theCallback){
    var waitTime = Math.floor(Math.random() * (maxTime + 1) )    
    if(theNumber%2){        
            setTimeout(function(){
                theCallback(new Error('The number is odd !'));
            },waitTime);
        }
        else{            
            setTimeout(function(){
                theCallback(null,theNumber*2);
            },waitTime);
        }
}
// Callback function
function ProcessResult(err,result){
        if(err){
            console.log(err.message);
        }else{
            console.log('Result is : ' + result);
        }
}

// var ProcessResult = (err,result) =>{
//     if(err){
//         console.log(err.message);
//     }else{
//         console.log('Result is : ' + result);
//     }
// }


EvenNumberDoubler(10,ProcessResult);
EvenNumberDoubler(3,ProcessResult);
EvenNumberDoubler(7,ProcessResult);
EvenNumberDoubler(6,ProcessResult);
console.log('Program Ended !');



