// ES 6 -> ECMAScript 6 | ES 2015 (standard of javascript)

function Add(x,y){
    return x + y;
}

// function as an expression
var Add = function(x,y){
    return x + y;
}

// ES 6-> Arrow functions

var Add = (x,y) => {
    return x+y;
}

// OR
var Add = (x,y) => x + y;
console.log(Add(30,40));