var fs = require('fs');

// Non-blocking
fs.readFile('Data.txt',function(err,dataFromFile){
    if(err){
        console.log('Could not read from file !');
    }
    else{
        console.log('Reading File Async : ' + dataFromFile.toString());
    }
});

// Blocking Code 
// var content = fs.readFileSync('Data.txt');
// console.log(content.toString());

console.log('Program ended..');
