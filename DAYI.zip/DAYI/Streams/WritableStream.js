const axios = require('axios').default;
var fs = require('fs');
 
//var response = "";
// Make a request for a user with a given ID
axios.get('http://www.google.com')
  .then(function (response) {
    // handle success
    fs.writeFile('GoogleResponse.html',response.data,function(err){
        if(err){
            console.log(err)
        }
    })
  });