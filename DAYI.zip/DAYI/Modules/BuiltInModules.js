//1. BuiltIn (Default) -> When node is installed [http,fs,os]
//2. User Defined Modules
//3. 3rd Party modules -> npm -> Which are installed using npm utility (node package manager)

var os = require('os');
console.log(os.cpus()[0]);
