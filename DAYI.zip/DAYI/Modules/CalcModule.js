// var MathModule = require('./MathModule');
// console.log(MathModule.Addition(30,50));

// Selective in importing !
var AdditionFunc = require('./MathModule').Addition;
console.log(AdditionFunc(20,40));