function Add(x,y){    return x + y;}
function Multiplication(x,y){    return x * y;}
function Division(x,y){    return x / y;}
//console.log(Add(10,20));
// module.exports.Addition = Add;
// module.exports.Product = Multiplication;

module.exports = {
    Addition:Add,
    Product:Multiplication
}