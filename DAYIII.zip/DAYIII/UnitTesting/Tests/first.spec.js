// Test suite and test cases
// jasmine js -> describe (test suite) | it(test cases)

describe("A suite is just a function", function() {
    var a;  
    it("test is a is true", function() {
      a = true;  
      expect(a).toBe(true); // matches
    });
    it("test is a is not to be true", function() {
        a = false;  
        expect(a).not.toBe(true); // matchers
      });
  });