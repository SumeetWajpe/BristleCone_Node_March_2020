var fs = require('fs');

fs.mkdir('temp',function(err){
    if(err){

    }else{
        fs.exists('temp',(exists)=>{
            if(exists){
                process.chdir('temp');
                fs.writeFile('Test.txt',"This is a message to be written in file !",(err)=>{
                    if(err){
                        console.log(err);
                    }else{
                        fs.readFile('Test.txt',(err,data)=>{
                                console.log(data.toString());
                        });
                    }
                })
            }
        })
    }
});

console.log('Program Ended..')