// var buff = new Buffer('Sample Data to be written in Buffer !');
// console.log(buff);
// console.log(buff.toString());
// console.log(buff.toString('UTF-8'));
// console.log(buff.toString('base64'));
// console.log(buff.length);

// FileStream
// Node app make an ajax call using axios [temp store it in buffer]
// Combine multiple file contents or responses from different api

var buffWithSize = Buffer.alloc(250);
var len = buffWithSize.write('Hello Buffer with size !');
console.log('Length Written : ' + len);
console.log('Total Buffer Size : ' + buffWithSize.length);

var buffer1 = new Buffer('This is data from Buffer 1 !');
var buffer2 = new Buffer('This is data from Buffer 2 !');

var buffer3 = Buffer.concat([buffer1,buffer2]);
console.log(buffer3.length);
