// ClientPeer                                   //ServerPeer
// html                                             // js

//on  -> to receive message by ServerPeer/ClientPeer
//emit -> to sent message by ServerPeer/ClientPeer

var socket = require('socket.io'); // npm i socket.io
var http = require('http');
var fs = require('fs');

var server = http.createServer((req,res)=>{
    fs.readFile(__dirname+"/ClientPeer.html",function(err,data){
      if(err){

      }else{
        res.writeHead(200,{'Content-Type':'text/html'});
        res.end(data);
      }
    });
});
server.listen(4000,'127.0.0.1',()=>{
    console.log('Server running @ 4000 !');
});
var io = socket.listen(server);
io.sockets.on('connection',(skt)=>{
    setInterval(function(){
        var dataToBeSent = new Date();
        skt.emit('messageFromServerPeer',
        dataToBeSent);
    },2000);

    skt.on('messageFromClientPeer',
    (dataFromClient)=>{
            console.log('Data received  : ' 
            + dataFromClient);
    });
});