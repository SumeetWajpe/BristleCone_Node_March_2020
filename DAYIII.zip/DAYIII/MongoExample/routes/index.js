var express = require('express');
var router = express.Router();
var mongodb = require('mongodb'); // npm

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});


router.get('/products',(req,res)=>{
  // 1. connect to db [connection string->port , ip address]
  // 2. access the db/collection
  // 3. find the records
  // 4. render the records using pug engine ! (pass products data to products.pug file)

  var MongoClient = mongodb.MongoClient;
  var url = "mongodb://localhost:27017";
  MongoClient.connect(url,{useNewUrlParser:true},(err,db)=>{
          if(err){
            console.log(err);
          }else{
            console.log(db);
            var collection = db.db('BConeDB').collection('products');
            // Find all records / Select * from ..
            collection.find({}).toArray((err,result)=>{
                if(err){
                  console.log(err);
                }else{
                  console.log(result.length);
                  // res.json(result); // for SPA
                  res.render('products',{title:'List of Products',products:result}); // For Traditional web app
                }
            })
          }
  });
});

module.exports = router;
